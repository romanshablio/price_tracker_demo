import { d as defineEventHandler, g as getQuery, c as createError } from '../../nitro/nitro.mjs';
import pkg from 'pg';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const { Pool } = pkg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
const prices_get = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const { period = "day", start, end } = query;
    let sqlQuery = "SELECT price, timestamp FROM bitcoin_prices";
    let params = [];
    if (start && end) {
      sqlQuery += " WHERE timestamp BETWEEN $1 AND $2";
      params = [start, end];
    } else {
      const now = /* @__PURE__ */ new Date();
      let startDate;
      switch (period) {
        case "week":
          startDate = new Date(now.setDate(now.getDate() - 7));
          break;
        case "month":
          startDate = new Date(now.setMonth(now.getMonth() - 1));
          break;
        case "year":
          startDate = new Date(now.setFullYear(now.getFullYear() - 1));
          break;
        default:
          startDate = new Date(now.setDate(now.getDate() - 1));
      }
      sqlQuery += " WHERE timestamp >= $1";
      params = [startDate];
    }
    sqlQuery += " ORDER BY timestamp ASC";
    const result = await pool.query(sqlQuery, params);
    return result.rows;
  } catch (error) {
    console.error("Error fetching prices:", error);
    throw createError({
      statusCode: 500,
      message: "Error fetching prices from database"
    });
  }
});

export { prices_get as default };
//# sourceMappingURL=prices.get.mjs.map
