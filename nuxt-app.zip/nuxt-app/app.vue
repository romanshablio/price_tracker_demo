<template>
  <div class="container mx-auto p-4">
    <h1 class="text-3xl font-bold mb-6">Bitcoin Price Tracker</h1>
    
    <div class="mb-6">
      <select v-model="selectedPeriod" class="p-2 border rounded">
        <option value="day">Last 24 hours</option>
        <option value="week">Last week</option>
        <option value="month">Last month</option>
        <option value="year">Last year</option>
      </select>
      
      <div class="mt-4">
        <label class="block mb-2">Custom Date Range:</label>
        <div class="flex gap-4">
          <input type="date" v-model="startDate" class="p-2 border rounded">
          <input type="date" v-model="endDate" class="p-2 border rounded">
        </div>
      </div>
    </div>

    <div class="bg-white p-4 rounded shadow">
      <Line v-if="chartData" :data="chartData" :options="chartOptions" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { Line } from 'vue-chartjs'
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

const selectedPeriod = ref('day')
const startDate = ref('')
const endDate = ref('')
const chartData = ref(null)
const prices = ref([])

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    y: {
      beginAtZero: false
    }
  }
}

async function fetchPrices() {
  try {
    const response = await fetch(`/api/prices?period=${selectedPeriod.value}&start=${startDate.value}&end=${endDate.value}`)
    const data = await response.json()
    prices.value = data
    
    chartData.value = {
      labels: data.map(item => new Date(item.timestamp).toLocaleString()),
      datasets: [
        {
          label: 'Bitcoin Price (USD)',
          data: data.map(item => item.price),
          borderColor: '#f59e0b',
          tension: 0.1
        }
      ]
    }
  } catch (error) {
    console.error('Error fetching prices:', error)
  }
}

watch([selectedPeriod, startDate, endDate], () => {
  fetchPrices()
})

onMounted(() => {
  fetchPrices()
})
</script>

<style>
.container {
  max-width: 1200px;
  margin: 0 auto;
}
</style> 