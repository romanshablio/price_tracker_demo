// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  srcDir: './',
  compatibilityDate: '2024-03-27',
  runtimeConfig: {
    public: {
      apiBase: process.env.API_BASE || 'http://localhost:3000'
    }
  },
  ssr: true,
  app: {
    head: {
      title: 'Bitcoin Price Tracker',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: 'Bitcoin price tracking application' }
      ]
    }
  },
  nitro: {
    preset: 'node-server',
    prerender: {
      crawlLinks: true,
      routes: ['/']
    },
    routeRules: {
      '/api/**': {
        proxy: 'http://price-service:3000/api/**'
      }
    }
  },
  modules: [
    '@nuxtjs/tailwindcss'
  ]
})
